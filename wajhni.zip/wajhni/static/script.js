
/* ---------- palette for charts ---------- */
const C = {
  sage700:'#4F7A47', sage600:'#66925A', sage500:'#7FA873', sage400:'#9AC08B', sage300:'#B9D1AE', sage200:'#DCE8D3',
  brown700:'#7C5C3B', brown600:'#8F6C46', brown500:'#A9825A', brown400:'#BE9C6F', sand200:'#E1D2B2', sand100:'#F2E9D8',
  brick:'#B5544A', ink:'#453D33', inkLight:'#9C8F7A'
};
Chart.defaults.font.family = "'Tajawal', sans-serif";
Chart.defaults.color = C.ink;


/* ---------- chart instance registry (needed so polling can safely destroy + recreate charts) ---------- */
const chartRegistry = {};
function destroyAllCharts(){
  Object.keys(chartRegistry).forEach(k=>{
    if(chartRegistry[k]){ chartRegistry[k].destroy(); }
  });
  for(const k in chartRegistry) delete chartRegistry[k];
}

/* ---------- nav switching (attached once, not on every poll) ---------- */
function initNav(){
  document.querySelectorAll('.navitem').forEach(item=>{
    item.addEventListener('click', ()=>{
      document.querySelectorAll('.navitem').forEach(i=>i.classList.remove('active'));
      document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
      item.classList.add('active');
      document.getElementById(item.dataset.page).classList.add('active');
    });
  });
}

/* =====================================================================
   renderDashboard(DATA) — the single entry point that (re)draws the
   entire dashboard from a DATA object. Called once on page load, then
   again every polling cycle with fresh data from GET /dashboard-data.
   All KPIs, charts, tables, the Linear Regression forecast, and the
   Rule-Based Recommendation Engine recompute here, every single call.
   ===================================================================== */
function renderDashboard(DATA){
  destroyAllCharts();

/* ---------- animated KPI count ---------- */
function animateCount(el, to){
  let start=0; const dur=900; const t0=performance.now();
  function step(t){
    const p=Math.min((t-t0)/dur,1);
    el.textContent = Math.round(start + (to-start)*p).toLocaleString('en-US');
    if(p<1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
animateCount(document.getElementById('kpi-total'), DATA.kpi.total);

/* ---------- تحديث نص "الفترة" وعدد المستفيدين ديناميكياً بدل القيم الثابتة ---------- */
const ARABIC_MONTHS_HDR = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
function monthLabelToArabicHdr(label){
  const [y,m] = label.split('-').map(Number);
  return `${ARABIC_MONTHS_HDR[m-1]} ${y}`;
}
if(DATA.monthly && DATA.monthly.length){
  const firstArabic = monthLabelToArabicHdr(DATA.monthly[0].month);
  const lastArabic = monthLabelToArabicHdr(DATA.monthly[DATA.monthly.length-1].month);
  const periodEl = document.getElementById('periodChipValue');
  if(periodEl) periodEl.textContent = `${firstArabic} – ${lastArabic}`;
  const updatedEl = document.getElementById('dataUpdatedChip');
  if(updatedEl) updatedEl.textContent = `بيانات محدثة حتى ${lastArabic}`;
}
const beneficiariesTotalEl = document.getElementById('beneficiariesTotalValue');
if(beneficiariesTotalEl) beneficiariesTotalEl.textContent = DATA.kpi.total.toLocaleString('en-US');

/* ================= PAGE 1 ================= */
chartRegistry['chartTrend'] = new Chart(document.getElementById('chartTrend'), {
  type:'bar',
  data:{
    labels: DATA.monthly.map(m=>m.month.replace('2026-','')),
    datasets:[
      {type:'bar', label:'عدد الطلبات', data:DATA.monthly.map(m=>m.count),
        backgroundColor:C.brown400, borderRadius:6, yAxisID:'y', order:2, barPercentage:.55},
      {type:'line', label:'متوسط الرضا %', data:DATA.monthly.map(m=>m.avg_rating),
        borderColor:C.sage600||C.sage500, backgroundColor:C.sage400, tension:.4, yAxisID:'y1',
        pointRadius:4, pointBackgroundColor:C.sage700, borderWidth:3, order:1}
    ]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    interaction:{mode:'index', intersect:false},
    plugins:{legend:{position:'bottom', labels:{boxWidth:10, usePointStyle:true}}},
    scales:{
      y:{position:'left', grid:{color:C.sand200}, title:{display:true, text:'عدد الطلبات', font:{size:10.5}}},
      y1:{position:'right', min:75, max:95, grid:{display:false}, title:{display:true, text:'الرضا %', font:{size:10.5}}}
    }
  }
});

chartRegistry['chartChannel'] = new Chart(document.getElementById('chartChannel'), {
  type:'doughnut',
  data:{ labels:Object.keys(DATA.channel), datasets:[{data:Object.values(DATA.channel),
    backgroundColor:[C.sage500, C.sage200], borderWidth:3, borderColor:'#fff'}] },
  options:{responsive:true, maintainAspectRatio:false, cutout:'62%',
    plugins:{legend:{display:false}, tooltip:{callbacks:{}}}}
});
chartRegistry['chartSlaWait'] = new Chart(document.getElementById('chartSlaWait'), {
  type:'doughnut',
  data:{ labels:['ضمن الهدف','تجاوز'], datasets:[{data:[DATA.sla.wait['لا'],DATA.sla.wait['نعم']],
    backgroundColor:[C.sage400, C.brick], borderWidth:3, borderColor:'#fff'}] },
  options:{responsive:true, maintainAspectRatio:false, cutout:'62%', plugins:{legend:{display:false}}}
});
chartRegistry['chartSlaService'] = new Chart(document.getElementById('chartSlaService'), {
  type:'doughnut',
  data:{ labels:['ضمن الهدف','تجاوز'], datasets:[{data:[DATA.sla.service['لا'],DATA.sla.service['نعم']],
    backgroundColor:[C.sage400, C.brick], borderWidth:3, borderColor:'#fff'}] },
  options:{responsive:true, maintainAspectRatio:false, cutout:'62%', plugins:{legend:{display:false}}}
});
document.querySelector('#page-overview .grid-2 .pie-duo').insertAdjacentHTML('afterend', `
  <div class="legend-row">
    <div class="legend-item"><span class="legend-swatch" style="background:${C.sage500}"></span> إلكتروني</div>
    <div class="legend-item"><span class="legend-swatch" style="background:${C.sage200}"></span> حضوري بالفرع</div>
    <div class="legend-item"><span class="legend-swatch" style="background:${C.sage400}"></span> ضمن الهدف</div>
    <div class="legend-item"><span class="legend-swatch" style="background:${C.brick}"></span> تجاوز الهدف</div>
  </div>`);

document.getElementById('serviceCountBadge').textContent = `من إجمالي ${DATA.total_unique_services} خدمة`;
chartRegistry['chartTopServices'] = new Chart(document.getElementById('chartTopServices'), {
  data:{
    labels: DATA.top_services.map(s=>s.name.length>16?s.name.slice(0,15)+'…':s.name),
    datasets:[
      {type:'bar', label:'عدد الطلبات', data:DATA.top_services.map(s=>s.count),
        backgroundColor:C.sage500, borderRadius:6, yAxisID:'y', order:2},
      {type:'line', label:'النسبة التراكمية %', data:DATA.top_services.map(s=>s.cum_pct),
        borderColor:C.brown600, backgroundColor:C.brown400, tension:.3, yAxisID:'y1',
        pointRadius:3, borderWidth:2.5, borderDash:[4,3], order:1}
    ]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom', labels:{boxWidth:10, font:{size:10}}}},
    scales:{
      x:{ticks:{font:{size:9}}, grid:{display:false}},
      y:{position:'left', grid:{color:C.sand100}, title:{display:true,text:'عدد الطلبات',font:{size:10}}},
      y1:{position:'right', min:0, max:100, grid:{display:false}, title:{display:true,text:'تراكمي %',font:{size:10}}}
    }
  }
});

const entityColors = [C.sage700,C.sage600,C.sage500,C.sage400,C.sage300,C.brown400,C.brown500,C.brown600,C.sand200,C.brick,C.ink,C.sage200,C.brown700];
chartRegistry['chartEntity'] = new Chart(document.getElementById('chartEntity'), {
  type:'bar',
  data:{
    labels: DATA.entity_distribution.map(e=>e.name),
    datasets:[{label:'عدد الطلبات', data:DATA.entity_distribution.map(e=>e.count),
      backgroundColor: DATA.entity_distribution.map((e,i)=>entityColors[i%entityColors.length]), borderRadius:5}]
  },
  options:{
    indexAxis:'y',
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{ x:{grid:{color:C.sand100}}, y:{grid:{display:false}, ticks:{font:{size:10}}} }
  }
});

/* heatmap */
function heatColor(v, max){
  const t = max>0 ? v/max : 0;
  const c1=[242,233,216], c2=[79,122,71];
  const c = c1.map((x,i)=>Math.round(x+(c2[i]-x)*t));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
const hm = DATA.heatmap;
let heatHtml = `<div class="heatmap-hdr"></div>` + hm.bins.map(b=>`<div class="heatmap-hdr">${b}</div>`).join('');
hm.matrix.forEach(row=>{
  heatHtml += `<div class="heatmap-daylabel">${row.day}</div>`;
  row.values.forEach(v=>{
    heatHtml += `<div class="heatmap-cell" style="background:${heatColor(v,hm.max)}" title="${row.day} ${v} طلب">${v||''}</div>`;
  });
});
document.getElementById('heatmapGrid').innerHTML = heatHtml;

/* ================= PAGE 2 ================= */
const satCats = ['ممتاز','جيد جدًا','جيد','متوسط','ضعيف'];
const satColors = {'ممتاز':C.sage700,'جيد جدًا':C.sage400,'جيد':C.sand200,'متوسط':C.brown500,'ضعيف':C.brick};
const satLabels = DATA.satisfaction_breakdown.map(d=>`${d.age} (${d.gender==='ذكر'?'ذكور':'إناث'})`);
chartRegistry['chartSatisfaction'] = new Chart(document.getElementById('chartSatisfaction'), {
  type:'bar',
  data:{
    labels: satLabels,
    datasets: satCats.map(cat=>({
      label:cat,
      data:DATA.satisfaction_breakdown.map(d=>d.pct[cat]||0),
      backgroundColor:satColors[cat],
      stack:'s'
    }))
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom', labels:{boxWidth:10, font:{size:10.5}}}},
    scales:{
      x:{stacked:true, ticks:{font:{size:9.5}}, grid:{display:false}},
      y:{stacked:true, max:100, grid:{color:C.sand100}, title:{display:true, text:'النسبة %', font:{size:10.5}}}
    }
  }
});

/* demographics */
const genderD = DATA.demographics['الجنس'];
const typeD = DATA.demographics['نوع المستفيد'];
document.getElementById('genderStats').innerHTML = genderD.map(g=>`
  <div class="stat-chip"><div class="n">${g.pct}%</div><div class="l">${g.label==='ذكر'?'ذكور':'إناث'} — ${g.count.toLocaleString('en-US')}</div></div>`).join('');
document.getElementById('typeStats').innerHTML = typeD.map(g=>`
  <div class="stat-chip"><div class="n">${g.pct}%</div><div class="l">${g.label} — ${g.count.toLocaleString('en-US')}</div></div>`).join('');

const nat = DATA.demographics['الجنسية'];
const maxNat = Math.max(...nat.map(n=>n.count));
document.getElementById('nationalityBody').innerHTML = nat.map(n=>`
  <tr class="${n.label==='سعودي'?'highlight':''}">
    <td>${n.label}</td>
    <td class="bar-cell" style="min-width:120px;">
      <div class="bar-track"><div class="bar-fill" style="width:${n.count/maxNat*100}%"></div></div>
      <span>${n.count.toLocaleString('en-US')}</span>
    </td>
    <td>${n.pct}%</td>
  </tr>`).join('');

chartRegistry['chartAgeVolume'] = new Chart(document.getElementById('chartAgeVolume'), {
  data:{
    labels: DATA.age_volume.map(a=>a.age),
    datasets:[
      {type:'bar', label:'عدد الطلبات', data:DATA.age_volume.map(a=>a.count),
        backgroundColor:C.sage500, borderRadius:8, yAxisID:'y', order:2, barPercentage:.55},
      {type:'line', label:'متوسط الرضا %', data:DATA.age_volume.map(a=>a.avg_rating),
        borderColor:C.brown600, backgroundColor:C.brown400, tension:.3, yAxisID:'y1',
        pointRadius:4, pointBackgroundColor:C.brown700, borderWidth:2.5, order:1}
    ]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom', labels:{boxWidth:10, font:{size:10.5}}}},
    scales:{
      y:{position:'left', grid:{color:C.sand100}, title:{display:true,text:'عدد الطلبات',font:{size:10.5}}},
      y1:{position:'right', min:75, max:95, grid:{display:false}, title:{display:true,text:'الرضا %',font:{size:10.5}}}
    }
  }
});

/* ================= PAGE 3 ================= */
const branchColors = [C.brown500, C.sage500, C.brown400, C.sage400];
const maxCount = Math.max(...DATA.branches.map(b=>b.count));
document.getElementById('branchBars').innerHTML = DATA.branches
  .slice().sort((a,b)=>b.count-a.count)
  .map((b,i)=>`
    <div class="branch-bar-row">
      <div class="branch-name">${b.name}</div>
      <div class="branch-track">
        <div class="branch-fill" style="width:${b.count/maxCount*100}%; background:${branchColors[i%4]}">${b.count.toLocaleString('en-US')}</div>
      </div>
      <div class="branch-badge">★ ${b.avg_rating}%</div>
    </div>`).join('');

chartRegistry['chartBranchTimes'] = new Chart(document.getElementById('chartBranchTimes'), {
  type:'bar',
  data:{
    labels: DATA.branches.map(b=>b.name),
    datasets:[
      {label:'متوسط الانتظار', data:DATA.branches.map(b=>b.avg_wait), backgroundColor:C.brown500, borderRadius:6},
      {label:'متوسط الخدمة', data:DATA.branches.map(b=>b.avg_service), backgroundColor:C.sage400, borderRadius:6}
    ]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{position:'bottom', labels:{boxWidth:10, font:{size:10.5}}}},
    scales:{ x:{grid:{display:false}, ticks:{font:{size:10}}}, y:{grid:{color:C.sand100}, title:{display:true,text:'دقائق',font:{size:10.5}}} }
  }
});

/* ================= PAGE 4 : FORECAST — REAL LINEAR REGRESSION (Least Squares, no libraries) ================= */

/** Fits y = slope*x + intercept to (xValues, yValues) using Ordinary Least Squares. */
function calculateLinearRegression(xValues, yValues){
  const n = xValues.length;
  const meanX = xValues.reduce((s,v)=>s+v,0)/n;
  const meanY = yValues.reduce((s,v)=>s+v,0)/n;
  let num = 0, den = 0;
  for(let i=0;i<n;i++){
    num += (xValues[i]-meanX)*(yValues[i]-meanY);
    den += (xValues[i]-meanX)*(xValues[i]-meanX);
  }
  const slope = den !== 0 ? num/den : 0;
  const intercept = meanY - slope*meanX;
  return { slope, intercept };
}

/** Coefficient of determination (R²) for the fitted line. */
function calculateRSquared(xValues, yValues, slope, intercept){
  const n = xValues.length;
  const meanY = yValues.reduce((s,v)=>s+v,0)/n;
  let ssRes = 0, ssTot = 0;
  for(let i=0;i<n;i++){
    const predicted = slope*xValues[i] + intercept;
    ssRes += Math.pow(yValues[i]-predicted, 2);
    ssTot += Math.pow(yValues[i]-meanY, 2);
  }
  return ssTot !== 0 ? 1 - (ssRes/ssTot) : 1;
}

/** Mean Absolute Error of the fitted line against the historical points. */
function calculateMAE(xValues, yValues, slope, intercept){
  const n = xValues.length;
  let sumAbsErr = 0;
  for(let i=0;i<n;i++){
    const predicted = slope*xValues[i] + intercept;
    sumAbsErr += Math.abs(yValues[i]-predicted);
  }
  return sumAbsErr/n;
}

/** Computes the YYYY-MM label that follows the last historical month label. */
function getNextMonthLabel(lastMonthLabel){
  const [y, m] = lastMonthLabel.split('-').map(Number);
  const nextM = m === 12 ? 1 : m+1;
  const nextY = m === 12 ? y+1 : y;
  return `${nextY}-${String(nextM).padStart(2,'0')}`;
}

const ARABIC_MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
function monthLabelToArabic(label){
  const [y,m] = label.split('-').map(Number);
  return `${ARABIC_MONTHS[m-1]} ${y}`;
}

/**
 * Trains a Linear Regression model on the historical monthly request counts
 * found in DATA.monthly and predicts the next month's request volume.
 * Fully derived from DATA — no hardcoded values.
 */
function predictNextMonth(monthlyData){
  const xValues = monthlyData.map((m,i)=>i);
  const yValues = monthlyData.map(m=>m.count);
  const { slope, intercept } = calculateLinearRegression(xValues, yValues);
  const r2 = calculateRSquared(xValues, yValues, slope, intercept);
  const mae = calculateMAE(xValues, yValues, slope, intercept);
  const nextX = monthlyData.length;
  const predictedRaw = slope*nextX + intercept;
  const predicted = Math.max(0, Math.round(predictedRaw));
  const lastMonth = monthlyData[monthlyData.length-1];
  const nextLabel = getNextMonthLabel(lastMonth.month);
  return {
    slope, intercept, r2, mae, predicted,
    nextLabel, nextLabelArabic: monthLabelToArabic(nextLabel),
    lastMonth, historicalLabels: monthlyData.map(m=>m.month), historicalValues: yValues
  };
}

/** Renders the forecast line chart from historical data + the regression-derived forecast point. */
function updateForecastChart(forecastResult){
  const histLabels = forecastResult.historicalLabels.map(m=>m.replace(/^\d{4}-/,''));
  const forecastLabel = forecastResult.nextLabel.replace(/^\d{4}-/,'');
  return chartRegistry['chartForecast'] = new Chart(document.getElementById('chartForecast'), {
    type:'line',
    data:{
      labels:[...histLabels, forecastLabel],
      datasets:[
        {label:'فعلي', data:[...forecastResult.historicalValues, null],
          borderColor:C.sage600||C.sage500, backgroundColor:'rgba(127,168,115,.15)', fill:true, tension:.35, pointRadius:4, borderWidth:3},
        {label:'توقع (Linear Regression)', data:[...Array(forecastResult.historicalValues.length-1).fill(null), forecastResult.historicalValues[forecastResult.historicalValues.length-1], forecastResult.predicted],
          borderColor:C.brown500, borderDash:[6,5], tension:.2, pointRadius:[0,6], borderWidth:3, fill:false}
      ]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{legend:{position:'bottom', labels:{boxWidth:10, font:{size:10.5}}}},
      scales:{ y:{grid:{color:C.sand100}, title:{display:true, text:'عدد الطلبات', font:{size:10.5}}} }
    }
  });
}

/** Updates the forecast badge/label text in-place (existing DOM node — no HTML/CSS changes). */
function updateForecastText(forecastResult){
  const badge = document.querySelector('#page-predictive .forecast-badge');
  if(badge) badge.textContent = `توقع ${forecastResult.nextLabelArabic}`;
}

const forecastResult = predictNextMonth(DATA.monthly);
updateForecastChart(forecastResult);
updateForecastText(forecastResult);

/* SPC control chart - weekly wait time */
const spc = DATA.wait_spc;
const spcPointColors = spc.values.map(v => (v > spc.ucl || v < spc.lcl) ? C.brick : C.sage600);
chartRegistry['chartSpc'] = new Chart(document.getElementById('chartSpc'), {
  type:'line',
  data:{
    labels: spc.labels,
    datasets:[
      {label:'متوسط الانتظار الأسبوعي', data:spc.values, borderColor:C.sage600, backgroundColor:'rgba(102,146,90,.12)',
        fill:true, tension:.25, pointRadius:5, pointBackgroundColor:spcPointColors, borderWidth:2.5},
      {label:'المتوسط العام', data:spc.labels.map(()=>spc.mean), borderColor:C.ink, borderWidth:1.5, pointRadius:0, borderDash:[2,2]},
      {label:'الحد الأعلى (UCL)', data:spc.labels.map(()=>spc.ucl), borderColor:C.brick, borderWidth:1.5, pointRadius:0, borderDash:[6,4]},
      {label:'الحد الأدنى (LCL)', data:spc.labels.map(()=>spc.lcl), borderColor:C.brick, borderWidth:1.5, pointRadius:0, borderDash:[6,4]}
    ]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{ticks:{font:{size:9}}, grid:{display:false}},
      y:{grid:{color:C.sand100}, title:{display:true, text:'دقائق', font:{size:10.5}}}
    }
  }
});
document.getElementById('spcLegend').innerHTML = `
  <span><span class="spc-line-sample" style="border-color:${C.sage600}"></span>القراءة الأسبوعية</span>
  <span><span class="spc-line-sample" style="border-color:${C.ink}"></span>المتوسط العام (${spc.mean} د)</span>
  <span><span class="spc-line-sample" style="border-color:${C.brick}"></span>حدود الضبط (${spc.lcl} – ${spc.ucl} د)</span>
  <span>🔴 نقطة خارج الحدود = أسبوع يستدعي تحقيقاً تشغيلياً</span>`;

/* treemap (proportional flex boxes) */
function renderTreemap(containerId, title, items, colorScale){
  const total = items.reduce((s,i)=>s+i.value,0);
  const maxV = Math.max(...items.map(i=>i.value));
  const boxes = items.map(it=>{
    const grow = it.value;
    const t = it.value/maxV;
    const bg = colorScale(t);
    return `<div class="tmap-box" style="flex:${grow} 1 0; background:${bg};" title="${it.name}: ${it.value}">
      ${it.name}${it.id?`<small>${it.id}</small>`:''}<small>${it.value}</small>
    </div>`;
  }).join('');
  return `<div class="tmap-group"><div class="tmap-title">${title}</div><div class="tmap-row">${boxes}</div></div>`;
}
function greenBrownScale(t){
  // t in [0,1], 1 = darkest/highest impact
  const stops = [
    {p:0, c:[220,207,178]},   // light sand
    {p:.5, c:[154,192,139]},  // sage
    {p:1, c:[79,122,71]}      // deep sage
  ];
  let lo=stops[0], hi=stops[stops.length-1];
  for(let i=0;i<stops.length-1;i++){ if(t>=stops[i].p && t<=stops[i+1].p){ lo=stops[i]; hi=stops[i+1]; break; } }
  const span = hi.p-lo.p || 1;
  const f = (t-lo.p)/span;
  const c = lo.c.map((v,i)=>Math.round(v+(hi.c[i]-v)*f));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
function brownScale(t){
  const c1=[190,156,111], c2=[122,92,59];
  const c = c1.map((v,i)=>Math.round(v+(c2[i]-v)*t));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
document.getElementById('treemapWrap').innerHTML =
  renderTreemap('t1','بحسب الخدمة', DATA.breach_factors.services.map(s=>({name:s.name.length>14?s.name.slice(0,13)+'…':s.name, id:s.id, value:s.value})), greenBrownScale) +
  renderTreemap('t2','بحسب الأولوية', DATA.breach_factors.priority, brownScale) +
  renderTreemap('t3','بحسب وقت الذروة', DATA.breach_factors.hours, greenBrownScale);

/* ================= RULE-BASED RECOMMENDATION ENGINE (Business Rules — no ML, no AI) ================= */
/* Every rule below reads only from `context`, which is itself derived live
   from DATA (+ the Linear Regression forecastResult). No hardcoded outcomes:
   change the underlying data and every number, branch name, service name,
   severity, and which rules fire will change automatically. */

const SEV_TAG  = {critical:'حرج', warning:'تحذير', info:'معلومة', positive:'إيجابي'};
const SEV_ICON = {critical:'🔴', warning:'🟠', info:'🔵', positive:'🟢'};
const WAIT_TARGET_MIN = 30; /* operational target used by تجاوز_هدف_الانتظار in the source data */

/** Builds the single source of truth used by every business rule. */
function buildContext(DATA, forecastResult){
  const lastMonth = forecastResult.lastMonth;
  const forecastGrowthPct = Math.round((forecastResult.predicted-lastMonth.count)/lastMonth.count*1000)/10;

  const firstMonth = DATA.monthly[0];
  const monthlyGrowthPct = Math.round((lastMonth.count-firstMonth.count)/firstMonth.count*1000)/10;

  const slaBreachPct = Math.round(DATA.sla.wait['نعم']/(DATA.sla.wait['نعم']+DATA.sla.wait['لا'])*1000)/10;
  const avgWaitTime = DATA.kpi.avg_wait;

  const hoursArr = DATA.breach_factors.hours.slice().sort((a,b)=>b.value-a.value);
  const totalWaitBreach = DATA.breach_factors.total_wait_breach;
  const peakTop2 = hoursArr.slice(0,2);
  const peakWindow = hoursArr.slice(0, Math.min(4,hoursArr.length)).map(h=>h.name).sort();
  const peakConcentrationPct = totalWaitBreach ? Math.round(peakTop2.reduce((s,h)=>s+h.value,0)/totalWaitBreach*1000)/10 : 0;

  const totalReq = DATA.branches.reduce((s,b)=>s+b.count,0);
  const totalBranchBreach = DATA.branches.reduce((s,b)=>s+b.wait_breach,0);
  const branchScored = DATA.branches.map(b=>{
    const shareReq = Math.round(b.count/totalReq*1000)/10;
    const shareBreach = totalBranchBreach ? Math.round(b.wait_breach/totalBranchBreach*1000)/10 : 0;
    return {...b, shareReq, shareBreach, disprop: shareBreach-shareReq};
  });
  const busiestBranch = branchScored.slice().sort((a,b)=>b.disprop-a.disprop)[0];

  const mostRequestedService = DATA.top_services[0];

  const queueLoadPct = slaBreachPct; /* proportion of requests currently breaching the wait target = queue pressure */
  const queueLoadLevel = queueLoadPct>30 ? 'مرتفع' : queueLoadPct>15 ? 'متوسط' : 'منخفض';

  const spc = DATA.wait_spc;
  const spcMean = spc.mean;
  const spcStd = (spc.ucl-spc.mean)/2; /* ucl = mean + 2*std, per how wait_spc was built */
  const spcCV = spcMean ? Math.round(spcStd/spcMean*1000)/10 : 0;
  const weeklyTrend = spcCV < 8 ? 'مستقر' : 'متذبذب';
  let spcWorstIdx=0, spcBestIdx=0;
  spc.values.forEach((v,i)=>{ if(v>spc.values[spcWorstIdx]) spcWorstIdx=i; if(v<spc.values[spcBestIdx]) spcBestIdx=i; });

  const eligibleServices = DATA.service_stats.filter(s=>s.total>=15);
  const structural = eligibleServices.slice().sort((a,b)=>b.rate-a.rate).slice(0,2);

  const totalCh = Object.values(DATA.channel).reduce((s,v)=>s+v,0);
  const elecEntry = Object.entries(DATA.channel).find(([k])=>k.includes('إلكتروني'));
  const electronicChannelPct = elecEntry ? Math.round(elecEntry[1]/totalCh*1000)/10 : 0;

  const dominantPriority = DATA.priority_stats.slice().sort((a,b)=>b.breach-a.breach)[0];
  const totalPriBreach = DATA.priority_stats.reduce((s,p)=>s+p.breach,0);
  const dominantPriorityPct = Math.round(dominantPriority.breach/totalPriBreach*1000)/10;

  return {
    forecastResult, forecastGrowthPct, monthlyGrowthPct,
    slaBreachPct, avgWaitTime, waitTarget: WAIT_TARGET_MIN,
    peakTop2, peakWindow, peakConcentrationPct, totalWaitBreach,
    busiestBranch, mostRequestedService,
    queueLoadPct, queueLoadLevel,
    weeklyTrend, spcCV, spc, spcWorstIdx, spcBestIdx,
    structural, electronicChannelPct,
    dominantPriority, dominantPriorityPct
  };
}

/** Evaluates every business rule against `context`. Returns only the rules whose condition is true. */
function evaluateRules(context){
  const rules = [];

  /* Rule: Forecast Growth > 10% */
  if(context.forecastGrowthPct > 10){
    rules.push({
      priority: 9, sev: context.forecastGrowthPct>=20?'critical':'warning', icon:'📈',
      title:'نمو متوقع في حجم الطلبات',
      body:`يتوقع نموذج Linear Regression أن يبلغ عدد الطلبات <b>${context.forecastResult.predicted}</b> خلال الشهر القادم (${context.forecastResult.nextLabelArabic})، بزيادة <b>${context.forecastGrowthPct}%</b> عن آخر شهر مسجّل (${context.forecastResult.lastMonth.count} طلباً).`,
      action:'يوصى بزيادة عدد الموظفين استعداداً لزيادة الطلب.'
    });
  }
  /* Rule: Forecast Growth < 0 */
  else if(context.forecastGrowthPct < 0){
    rules.push({
      priority: 3, sev:'positive', icon:'📉',
      title:'انخفاض متوقع في حجم الطلبات',
      body:`يتوقع نموذج Linear Regression أن يبلغ عدد الطلبات <b>${context.forecastResult.predicted}</b> خلال الشهر القادم (${context.forecastResult.nextLabelArabic})، بانخفاض <b>${Math.abs(context.forecastGrowthPct)}%</b> عن آخر شهر مسجّل.`,
      action:'لا توجد حاجة لزيادة الموارد ويُنصح بالاستمرار على الطاقة التشغيلية الحالية.'
    });
  }
  /* Rule: 0% <= Forecast Growth <= 10% (moderate, still surfaced so a forecast card always exists) */
  else {
    rules.push({
      priority: 2, sev:'info', icon:'🔮',
      title:'نمو متوقع معتدل',
      body:`يتوقع نموذج Linear Regression أن يبلغ عدد الطلبات <b>${context.forecastResult.predicted}</b> خلال الشهر القادم (${context.forecastResult.nextLabelArabic})، بزيادة طفيفة قدرها <b>${context.forecastGrowthPct}%</b> فقط عن آخر شهر مسجّل.`,
      action:'نمو ضمن النطاق الطبيعي، يُنصح بالمتابعة الدورية دون تغييرات فورية.'
    });
  }

  /* Rule: SLA Breach > 20% */
  if(context.slaBreachPct > 20){
    rules.push({
      priority: context.slaBreachPct>=35?8:6, sev: context.slaBreachPct>=35?'critical':'warning', icon:'⏰',
      title:'تجاوز مرتفع لهدف الانتظار',
      body:`معدل تجاوز هدف الانتظار الحالي <b>${context.slaBreachPct}%</b> من إجمالي الطلبات، ويتركّز بشكل خاص بين الساعة <b>${context.peakTop2[0].name}</b> و<b>${context.peakTop2[1].name}</b> (نسبة ${context.peakConcentrationPct}% من إجمالي حالات التجاوز).`,
      action:`يوصى بزيادة عدد الكاونترات خلال ساعات الذروة (${context.peakWindow[0]}–${context.peakWindow[context.peakWindow.length-1]}).`
    });
  }

  /* Rule: Average Waiting Time > Target */
  if(context.avgWaitTime > context.waitTarget){
    rules.push({
      priority: 7, sev:'warning', icon:'⏳',
      title:'متوسط الانتظار يتجاوز الهدف التشغيلي',
      body:`متوسط مدة الانتظار الحالي <b>${context.avgWaitTime} دقيقة</b>، متجاوزاً الهدف التشغيلي المعتمد (${context.waitTarget} دقيقة).`,
      action:'يوصى بمراجعة إجراءات الخدمة لتقليل وقت الانتظار.'
    });
  }

  /* Rule: Queue Load مرتفع */
  if(context.queueLoadLevel === 'مرتفع'){
    rules.push({
      priority: 6, sev:'warning', icon:'🚦',
      title:'حمل مرتفع على الطابور',
      body:`نسبة الطلبات التي تتجاوز هدف الانتظار حالياً <b>${context.queueLoadPct}%</b>، وهو مؤشر على ضغط تشغيلي مرتفع على الطابور العام.`,
      action:'يوصى بإعادة توزيع العملاء على الكاونترات الأقل ازدحاماً.'
    });
  }

  /* Rule: أحد الفروع يمثل أعلى ضغط */
  if(context.busiestBranch && context.busiestBranch.disprop > 0){
    rules.push({
      priority: 5, sev: context.busiestBranch.disprop>=15?'critical':'warning', icon:'🏢',
      title:`ضغط غير متناسب في فرع ${context.busiestBranch.name}`,
      body:`فرع ${context.busiestBranch.name} يستقبل <b>${context.busiestBranch.shareReq}%</b> فقط من إجمالي الطلبات، لكنه مسؤول عن <b>${context.busiestBranch.shareBreach}%</b> من إجمالي تجاوزات هدف الانتظار.`,
      action:`يوصى بإعادة توزيع الموظفين على فرع ${context.busiestBranch.name}.`
    });
  }

  /* Rule: إحدى الخدمات تمثل أعلى عدد طلبات */
  if(context.mostRequestedService){
    rules.push({
      priority: 4, sev:'info', icon:'🧾',
      title:`"${context.mostRequestedService.name}" الأعلى طلباً في المركز`,
      body:`سجّلت خدمة "${context.mostRequestedService.name}" أعلى عدد طلبات في المركز (${context.mostRequestedService.count} طلباً، ${context.mostRequestedService.cum_pct}% من الإجمالي التراكمي).`,
      action:`يوصى بتخصيص كاونتر دائم لخدمة ${context.mostRequestedService.name}.`
    });
  }

  /* Rule: Weekly Trend مستقر / متذبذب */
  if(context.weeklyTrend === 'مستقر'){
    rules.push({
      priority: 1, sev:'positive', icon:'✅',
      title:'الاتجاه الأسبوعي مستقر',
      body:`تباين متوسط الانتظار الأسبوعي منخفض (معامل اختلاف ${context.spcCV}%)، وجميع الأسابيع ضمن حدود الضبط الإحصائي تقريباً.`,
      action:'الأداء مستقر ولا توجد مؤشرات تتطلب تدخلاً فورياً.'
    });
  } else {
    rules.push({
      priority: 6, sev:'warning', icon:'📊',
      title:'الاتجاه الأسبوعي متذبذب',
      body:`تباين متوسط الانتظار الأسبوعي مرتفع نسبياً (معامل اختلاف ${context.spcCV}%)، مع أسبوع ${context.spc.labels[context.spcWorstIdx]} مسجّلاً أعلى قيمة (${context.spc.values[context.spcWorstIdx]} دقيقة).`,
      action:'يوصى بمراجعة الجدولة الأسبوعية وتحديد سبب التذبذب.'
    });
  }

  /* Rule: Monthly Growth مرتفع */
  if(context.monthlyGrowthPct > 15){
    rules.push({
      priority: 7, sev:'warning', icon:'📆',
      title:'نمو تراكمي مرتفع خلال فترة البيانات',
      body:`ارتفع حجم الطلبات الشهري بنسبة <b>${context.monthlyGrowthPct}%</b> بين أول وآخر شهر في البيانات المتاحة.`,
      action:'يوصى بزيادة الطاقة التشغيلية خلال الشهر القادم.'
    });
  }

  /* Rule: خدمات ذات مشكلة إجرائية بنيوية (rate عالٍ بصرف النظر عن الحجم) */
  if(context.structural.length===2 && context.structural[0].rate>=45){
    rules.push({
      priority: 5, sev:'info', icon:'⚙️',
      title:'خدمات ذات مشكلة إجرائية بنيوية',
      body:`خدمتا "${context.structural[0].name}" و"${context.structural[1].name}" تسجلان أعلى معدل تجاوز في المركز (${context.structural[0].rate}% و${context.structural[1].rate}%) رغم حجم طلب معتدل — ما يشير لمشكلة في الإجراء نفسه وليس الحمل.`,
      action:'يوصى بمراجعة مستقلة لخطوات تنفيذ هاتين الخدمتين.'
    });
  }

  /* Rule: فرصة تحول رقمي (channel) */
  if(context.electronicChannelPct){
    rules.push({
      priority: 2, sev:'positive', icon:'💻',
      title:'فرصة تسريع التحول الرقمي',
      body:`<b>${context.electronicChannelPct}%</b> من الطلبات تُقدَّم إلكترونياً بالفعل، وخدمة "${context.mostRequestedService.name}" مرشحة ممتازة لأتمتة إضافية نظراً لتكرار طلبها.`,
      action:'يوصى بدفع المزيد من الطلبات نحو القناة الإلكترونية قبل موسم الذروة القادم.'
    });
  }

  /* Rule: هيمنة أولوية معينة على التجاوزات */
  if(context.dominantPriorityPct >= 55){
    rules.push({
      priority: 5, sev: context.dominantPriorityPct>=75?'critical':'warning', icon:'📋',
      title:`أولوية "${context.dominantPriority.name}" تستحوذ على معظم التجاوزات`,
      body:`<b>${context.dominantPriorityPct}%</b> من إجمالي تجاوزات هدف الانتظار تقع ضمن طلبات ذات أولوية "${context.dominantPriority.name}" (معدل تجاوز ${context.dominantPriority.rate}% لهذه الفئة).`,
      action:'يوصى بمراجعة مسار معالجة هذه الفئة من الطلبات تحديداً.'
    });
  }

  return rules;
}

/** Runs the rule engine, ranks results by priority, and returns the top recommendations. */
function generateRecommendations(context, maxCards){
  const evaluated = evaluateRules(context);
  const ranked = evaluated.slice().sort((a,b)=>b.priority-a.priority);
  return maxCards ? ranked.slice(0, maxCards) : ranked;
}

/** Renders recommendation cards into the existing #alertGrid container (markup/CSS untouched). */
function updateRecommendationCards(recommendations){
  document.getElementById('alertGrid').innerHTML = recommendations.map(r=>`
    <div class="alert-card sev-${r.sev}">
      <div class="alert-head">
        <div class="alert-icon">${r.icon}</div>
        <div class="alert-title">${r.title}</div>
        <div class="alert-tag">${SEV_TAG[r.sev]}</div>
      </div>
      <div class="alert-body">${r.body}</div>
      <div class="alert-action">💡 <span><b>الإجراء المقترح:</b> ${r.action}</span></div>
    </div>`).join('');
}

const engineContext = buildContext(DATA, forecastResult);
const recommendations = generateRecommendations(engineContext, 9);
updateRecommendationCards(recommendations);

/* ================= PAGE 5 : STAFF & COUNTERS ================= */
const SP = DATA.employees_page;
document.getElementById('staffCountChip').textContent = SP.total_employees;

const topEmp = SP.employees[0];
const bestCounter = SP.counters[0];
document.getElementById('staffKpiGrid').innerHTML = `
  <div class="kpi-card">
    <div class="kpi-top"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 10h18"/></svg></div></div>
    <div class="kpi-value">${SP.total_employees}</div>
    <div class="kpi-label">إجمالي عدد الموظفين</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-top"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path fill="currentColor" stroke="none" d="M12 2.8l2.7 5.9 6.4.7-4.8 4.4 1.3 6.4L12 16.9l-5.6 3.3 1.3-6.4-4.8-4.4 6.4-.7z"/></svg></div></div>
    <div class="kpi-value">${topEmp.id}</div>
    <div class="kpi-label">الأعلى كفاءة (${topEmp.efficiency_score}%)</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-top"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/></svg></div></div>
    <div class="kpi-value">${bestCounter.id}</div>
    <div class="kpi-label">الأكثر ازدحاماً (${bestCounter.count.toLocaleString('en-US')} طلب)</div>
  </div>
  <div class="kpi-card">
    <div class="kpi-top"><div class="kpi-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v3M12 18v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M3 12h3M18 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/><circle cx="12" cy="12" r="3.2"/></svg></div></div>
    <div class="kpi-value">${SP.breach_avg}<span style="font-size:15px;">%</span></div>
    <div class="kpi-label">متوسط تجاوز هدف الخدمة للموظف</div>
  </div>`;

/* leaderboard */
const topBranchColors = {'الرئيسي - رجال':C.brown500,'الرئيسي - نساء':C.sage500,'الدائري':C.brown400,'ينبع':C.sage400};
const maxScore = Math.max(...SP.employees.map(e=>e.efficiency_score));
document.getElementById('empLeaderboard').innerHTML = SP.employees.slice(0,10).map((e,i)=>`
  <div class="branch-bar-row">
    <div class="branch-name">#${i+1} ${e.id}</div>
    <div class="branch-track">
      <div class="branch-fill" style="width:${e.efficiency_score/maxScore*100}%; background:${topBranchColors[e.branch]||C.sage500}">${e.efficiency_score}%</div>
    </div>
    <div class="branch-badge">${e.count} طلب · ★${e.avg_rating}%</div>
  </div>`).join('');

/* counters chart */
const topCounters = SP.counters.slice(0,10);
chartRegistry['chartCounters'] = new Chart(document.getElementById('chartCounters'), {
  type:'bar',
  data:{
    labels: topCounters.map(c=>c.id),
    datasets:[{label:'عدد الطلبات', data:topCounters.map(c=>c.count), backgroundColor:C.brown400, borderRadius:6}]
  },
  options:{
    indexAxis:'y',
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{ x:{grid:{color:C.sand100}}, y:{grid:{display:false}} }
  }
});

/* quadrant scatter */
const quadColors = {
  'نجوم الأداء': C.sage600||C.sage500,
  'سريع لكن يحتاج تحسين الرضا': C.brown500,
  'دقيق لكن أبطأ من المتوسط': C.sage300,
  'يحتاج تدريب ومتابعة': C.brick
};
const quadGroups = {};
SP.employees.forEach(e=>{
  if(!quadGroups[e.quadrant]) quadGroups[e.quadrant] = [];
  quadGroups[e.quadrant].push({x:e.avg_service, y:e.avg_rating, id:e.id});
});
chartRegistry['chartQuadrant'] = new Chart(document.getElementById('chartQuadrant'), {
  type:'scatter',
  data:{
    datasets: Object.keys(quadGroups).map(q=>({
      label:q, data:quadGroups[q], backgroundColor:quadColors[q], pointRadius:6, pointHoverRadius:8
    }))
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{
      legend:{display:false},
      tooltip:{callbacks:{label:(ctx)=>`${ctx.raw.id}: ${ctx.raw.x} د · ${ctx.raw.y}%`}},
      annotation:undefined
    },
    scales:{
      x:{title:{display:true, text:'متوسط مدة الخدمة (دقيقة)', font:{size:10.5}}, grid:{color:C.sand100}},
      y:{title:{display:true, text:'متوسط الرضا %', font:{size:10.5}}, grid:{color:C.sand100}}
    }
  }
});
document.getElementById('quadrantLegend').innerHTML = Object.keys(quadColors).map(q=>`
  <div class="legend-item"><span class="legend-swatch" style="background:${quadColors[q]}"></span>${q}</div>`).join('');

/* expert stats + insights */
const corr = SP.correlation_service_rating;
const corrDesc = corr < -0.3 ? 'ارتباط عكسي واضح' : corr < -0.1 ? 'ارتباط عكسي ضعيف' : Math.abs(corr) <= 0.1 ? 'شبه منعدم' : 'ارتباط طردي';
document.getElementById('expertStats').innerHTML = `
  <div class="stat-chip"><div class="n">${corr}</div><div class="l">الارتباط: سرعة الخدمة × الرضا (${corrDesc})</div></div>
  <div class="stat-chip"><div class="n">±${SP.workload_std}</div><div class="l">انحراف معياري لحمل العمل (متوسط ${SP.workload_mean} طلب/موظف)</div></div>`;

const starCount = SP.employees.filter(e=>e.quadrant==='نجوم الأداء').length;
const riskCount = SP.employees.filter(e=>e.quadrant==='يحتاج تدريب ومتابعة').length;
const busiestCounters = SP.counters.slice(0,3).map(c=>c.id).join('، ');
document.getElementById('expertInsights').innerHTML = `
  <li>يوجد <b>${starCount}</b> موظفاً ضمن فئة "نجوم الأداء" (سرعة أعلى من الوسيط ورضا أعلى من الوسيط) — مرشحون مثاليون لتدريب الموظفين الجدد.</li>
  <li>الارتباط بين سرعة الخدمة والرضا ${corrDesc} (${corr})، ما يشير إلى أن سرعة الإنجاز وحدها لا تفسر رضا المستفيد؛ جودة التفاعل عامل مؤثر أيضاً.</li>
  <li>الكاونترات ${busiestCounters} هي الأكثر ازدحاماً؛ يُنصح بمراجعة جدولة المناوبات عليها لتفادي الاختناقات في أوقات الذروة.</li>
  <li><b>${riskCount}</b> موظفين ضمن فئة "يحتاج تدريب ومتابعة" (أبطأ من المتوسط ورضا أقل)؛ يُقترح برنامج تحسين أداء موجّه لهذه المجموعة خلال الربع القادم.</li>
  <li>تفاوت حمل العمل بين الموظفين (${SP.workload_mean}±${SP.workload_std} طلب) معتدل نسبياً، لكن يستحق المتابعة لضمان توزيع عادل للمهام.</li>`;

}

/* ---------- bootstrap: initial load + polling ---------- */
let _lastDashboardJSON = null;
function fetchAndRender(){
  fetch('/dashboard-data')
    .then(r => {
      if(!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(data => {
      const json = JSON.stringify(data);
      if(json === _lastDashboardJSON) return; /* البيانات لم تتغيّر — لا داعي لإعادة رسم كل شيء (يمنع الترميش) */
      _lastDashboardJSON = json;
      renderDashboard(data);
    })
    .catch(err => console.error('تعذّر تحديث لوحة المتابعة:', err));
}

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  fetchAndRender();
  setInterval(fetchAndRender, 2000); /* polling every 2 seconds */
});
