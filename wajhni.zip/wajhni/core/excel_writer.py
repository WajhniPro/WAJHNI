# -*- coding: utf-8 -*-
"""
core/excel_writer.py
=====================

يضيف سطراً جديداً إلى ورقة "طلبات_محسنة" داخل:
    data/sedco_dashboard_full_3000_formatted.xlsx

بعد كل تذكرة يُصدرها core/ticket_generator.py، بحيث يصبح ملف الإكسل
هو "مصدر الحقيقة الوحيد" المُحدَّث فوراً — و core/data_pipeline.py
يعيد قراءته وحساب كل مؤشرات Dashboard من جديد في الطلب التالي.

ملاحظة تصميمية مهمة (موثّقة للشفافية):
  عند إصدار التذكرة نعرف الخدمة ووقت الانتظار التقديري فوراً، لكن "التقييم"
  الفعلي للخدمة لا يُعرف إلا بعد أن يُنهي المستفيد خدمته فعلياً — وهو أمر
  خارج نطاق هذا المشروع الأكاديمي (لا يوجد شاشة تقييم بعد الخدمة).
  لأجل أن تعكس Dashboard التذكرة الجديدة فوراً وبشكل واقعي في كل المؤشرات
  (بما فيها الرضا)، نُنشئ سطراً "مكتملاً" يحاكي انتهاء الخدمة، بمدة خدمة
  تساوي الوقت التقديري للخدمة، وتقييم يُستخرج عشوائياً من توزيع واقعي مطابق
  لتوزيع البيانات التاريخية الفعلية في نفس الملف. هذا مناسب تماماً لعرض حي
  (Live Demo) لمشروع تخرج؛ في نظام إنتاجي حقيقي كان يجب تأجيل التقييم حتى
  انتهاء الخدمة الفعلية عبر شاشة تقييم منفصلة.
"""

import os
import random
import threading
from datetime import datetime

import openpyxl

SHEET_NAME = "طلبات_محسنة"

# فروع الكيوسك: نربط الجنس بفرع الرجال/النساء الرئيسي، مطابقة لبيانات الإكسل الأصلية
BRANCH_BY_GENDER = {
    "ذكر": ("BR-01", "الرئيسي - رجال"),
    "أنثى": ("BR-02", "الرئيسي - نساء"),
}

# جنسيات المقيمين الظاهرة فعلياً في البيانات التاريخية (تُستخدم عشوائياً لو "مقيم")
RESIDENT_NATIONALITIES = [
    "مصري", "يمني", "سوري", "هندي", "باكستاني", "بنغلاديشي",
    "فلبيني", "سوداني", "إندونيسي", "نيبالي", "أردني",
]

ARABIC_WEEKDAY = {
    0: "الاثنين", 1: "الثلاثاء", 2: "الأربعاء", 3: "الخميس",
    4: "الجمعة", 5: "السبت", 6: "الأحد",
}

WAIT_TARGET_MIN = 30
SERVICE_TARGET_MIN = 20

# قفل بسيط يمنع تضارب الكتابة لو وصل أكثر من طلب لإصدار تذكرة في نفس اللحظة
_write_lock = threading.Lock()


def _age_bucket(age: int) -> str:
    if age < 18:
        return "أقل من 18"
    if age <= 25:
        return "18-25"
    if age <= 35:
        return "26-35"
    if age <= 45:
        return "36-45"
    if age <= 55:
        return "46-55"
    return "56+"


def _rating_category(rating: int) -> str:
    if rating >= 90:
        return "ممتاز"
    if rating >= 80:
        return "جيد جدًا"
    if rating >= 70:
        return "جيد"
    if rating >= 60:
        return "متوسط"
    return "ضعيف"


def _pick_counter(ws, branch_name: str):
    """يختار كاونتر مناسب للفرع من الكاونترات الموجودة فعلياً في البيانات، أو يعيد None لو لم يوجد تطابق."""
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers)}
    seen = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[idx["اسم_الفرع"]] == branch_name and row[idx["معرف_الكاونتر"]]:
            seen.add(row[idx["معرف_الكاونتر"]])
    return random.choice(sorted(seen)) if seen else None


def _pick_employee(ws):
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers)}
    seen = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[idx["معرف_الموظف"]]:
            seen.add(row[idx["معرف_الموظف"]])
    return random.choice(sorted(seen)) if seen else None


def append_ticket_to_excel(excel_path: str, service_result: dict, ticket_result: dict,
                            gender: str, status: str) -> dict:
    """
    يضيف سطراً جديداً لورقة 'طلبات_محسنة' يمثل التذكرة التي أصدرها ticket_generator.py.

    service_result : نتيجة engine.process_request(...) — تحتوي service_id/service_name/department/...
    ticket_result   : نتيجة ticket_gen.generate(...) — تحتوي waiting_number/wait_info/...
    gender          : "ذكر" أو "أنثى"
    status          : "مواطن" أو "مقيم"

    يعيد قاموس بالسطر المُضاف (لأغراض اللوق/العرض فقط).
    """
    with _write_lock:
        wb = openpyxl.load_workbook(excel_path)  # data_only=False حتى لا نفقد الصيغ في الأوراق الأخرى
        ws = wb[SHEET_NAME]
        headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]

        now = datetime.now()
        today = now.date()

        next_seq = ws.max_row  # عدد الصفوف الحالي (بدون العنوان) + 1 تقريباً
        request_no = f"REQ-{today.strftime('%Y%m%d')}-{next_seq:05d}"
        txid = f"TX-{random.randint(1000000, 9999999)}"

        branch_id, branch_name = BRANCH_BY_GENDER.get(gender, BRANCH_BY_GENDER["ذكر"])

        if status == "مواطن":
            nationality = "سعودي"
        else:
            nationality = random.choice(RESIDENT_NATIONALITIES)

        age = random.randint(20, 58)
        estimated_service_min = int(service_result.get("estimated_time_minutes") or 15)
        wait_min = int(ticket_result.get("wait_info", {}).get("total_minutes") or 0)
        total_min = wait_min + estimated_service_min

        # تقييم واقعي: توزيع مائل نحو الإيجابي (نفس الطابع العام لبيانات المركز التاريخية)
        rating = round(random.triangular(60, 99, 88))
        rating = max(52, min(99, rating))

        employee_id = _pick_employee(ws)
        counter_id = _pick_counter(ws, branch_name)

        row_values = {
            "رقم_الطلب": request_no,
            "TXID": txid,
            "تاريخ_الزيارة": now,
            "وقت_الحضور": now.strftime("%H:%M"),
            "اليوم": ARABIC_WEEKDAY[today.weekday()],
            "الشهر": today.month,
            "السنة_الشهر": f"{today.year}-{today.month:02d}",
            "معرف_الفرع": branch_id,
            "اسم_الفرع": branch_name,
            "معرف_الخدمة": service_result.get("service_id"),
            "اسم_الجهة": service_result.get("department"),
            "اسم_الخدمة": service_result.get("service_name"),
            "الجنس": gender,
            "نوع_المستفيد": status,
            "الجنسية": nationality,
            "العمر": age,
            "الفئة_العمرية": _age_bucket(age),
            "قناة_الطلب": "حضوري في الفرع",
            "حالة_الطلب": "مكتمل",
            "الأولوية": "عادي",
            "مدة_الانتظار_دقيقة": wait_min,
            "مدة_الخدمة_دقيقة": estimated_service_min,
            "مدة_الإنجاز_الكلية_دقيقة": total_min,
            "التقييم_%": rating,
            "تصنيف_الرضا": _rating_category(rating),
            "معرف_الموظف": employee_id,
            "معرف_الكاونتر": counter_id,
            "تجاوز_هدف_الانتظار": "نعم" if wait_min > WAIT_TARGET_MIN else "لا",
            "تجاوز_هدف_الخدمة": "نعم" if estimated_service_min > SERVICE_TARGET_MIN else "لا",
            "مصدر_الصف": "نظام وجّهني — تذكرة مباشرة",
            "ملاحظة": f"تذكرة رقم {ticket_result.get('waiting_number', '')}",
        }

        new_row = [row_values.get(h) for h in headers]
        ws.append(new_row)
        wb.save(excel_path)
        wb.close()

        return row_values
