# -*- coding: utf-8 -*-
"""
core/data_pipeline.py
======================

المصدر الوحيد للبيانات في هذا المشروع هو:
    data/sedco_dashboard_full_3000_formatted.xlsx  (ورقة "طلبات_محسنة")

هذا الملف يقرأ تلك الورقة مباشرة في كل مرة تُطلب فيها بيانات Dashboard،
ويعيد بناء كل المؤشرات من الصفر (لا تخزين مؤقت لأي نتيجة نهائية) — بحيث
أي سطر جديد يُضاف إلى الإكسل (عبر تذكرة جديدة) ينعكس فوراً على الحسابات
في الطلب التالي لـ GET /dashboard-data.

لا يوجد Linear Regression ولا Rule Engine هنا عمداً: تلك المنطقة تعيش في
static/script.js (نفس الكود الذي كان يعمل على بيانات ثابتة سابقاً) وتُعاد
حسابها تلقائياً في كل دورة Polling على بيانات DATA.monthly الطازجة القادمة
من هنا. هذا يحافظ على نسخة واحدة فقط من منطق النموذج التنبؤي ومحرك التوصيات
بدل تكراره في Python و JavaScript.
"""

import math
import statistics
from collections import defaultdict
from datetime import datetime, timedelta

import openpyxl

SHEET_NAME = "طلبات_محسنة"
EXCEL_EPOCH = datetime(1899, 12, 30)

WAIT_TARGET_MIN = 30
SERVICE_TARGET_MIN = 20


# ---------------------------------------------------------------------------
# تحميل الصفوف الخام
# ---------------------------------------------------------------------------

def _to_date(value):
    """يحوّل قيمة تاريخ من الإكسل (قد تكون float/serial أو datetime/date) إلى datetime.date."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if hasattr(value, "year") and hasattr(value, "month"):  # datetime.date
        return value
    if isinstance(value, (int, float)):
        return (EXCEL_EPOCH + timedelta(days=math.floor(value))).date()
    return None


def load_rows(excel_path: str):
    """يفتح ملف الإكسل ويعيد قائمة قواميس (dict) — سطر لكل طلب، بعناوين الأعمدة كمفاتيح."""
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    ws = wb[SHEET_NAME]
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]

    rows = []
    for raw in ws.iter_rows(min_row=2, values_only=True):
        if raw[0] is None:  # سطر فارغ في نهاية الملف
            continue
        row = dict(zip(headers, raw))
        rows.append(row)
    wb.close()
    return rows


# ---------------------------------------------------------------------------
# دوال حساب كل قسم من أقسام Dashboard
# ---------------------------------------------------------------------------

def _kpi(rows):
    n = len(rows)
    if n == 0:
        return {"total": 0, "avg_wait": 0, "avg_service": 0, "avg_satisfaction": 0}
    avg_wait = sum(r.get("مدة_الانتظار_دقيقة") or 0 for r in rows) / n
    avg_service = sum(r.get("مدة_الخدمة_دقيقة") or 0 for r in rows) / n
    ratings = [r.get("التقييم_%") for r in rows if r.get("التقييم_%") is not None]
    avg_sat = sum(ratings) / len(ratings) if ratings else 0
    return {
        "total": n,
        "avg_wait": round(avg_wait, 1),
        "avg_service": round(avg_service, 1),
        "avg_satisfaction": round(avg_sat, 1),
    }


def _monthly(rows):
    buckets = defaultdict(lambda: {"count": 0, "rsum": 0, "rcount": 0})
    for r in rows:
        ym = r.get("السنة_الشهر")
        if not ym:
            continue
        b = buckets[ym]
        b["count"] += 1
        rating = r.get("التقييم_%")
        if rating is not None:
            b["rsum"] += rating
            b["rcount"] += 1
    out = []
    for ym in sorted(buckets.keys()):
        b = buckets[ym]
        avg_rating = round(b["rsum"] / b["rcount"], 1) if b["rcount"] else 0
        out.append({"month": ym, "count": b["count"], "avg_rating": avg_rating})
    return out


def _channel(rows):
    c = defaultdict(int)
    for r in rows:
        ch = r.get("قناة_الطلب")
        if ch:
            c[ch] += 1
    return dict(c)


def _sla(rows):
    wait = defaultdict(int)
    service = defaultdict(int)
    for r in rows:
        w = r.get("تجاوز_هدف_الانتظار")
        s = r.get("تجاوز_هدف_الخدمة")
        if w:
            wait[w] += 1
        if s:
            service[s] += 1
    return {"wait": dict(wait), "service": dict(service)}


def _satisfaction_breakdown(rows):
    age_order = ["أقل من 18", "18-25", "26-35", "36-45", "46-55", "56+"]
    cat_order = ["ممتاز", "جيد جدًا", "جيد", "متوسط", "ضعيف"]
    buckets = defaultdict(lambda: defaultdict(int))
    for r in rows:
        cat = r.get("تصنيف_الرضا")
        if not cat:
            continue
        key = (r.get("الفئة_العمرية"), r.get("الجنس"))
        buckets[key][cat] += 1

    out = []
    for age in age_order:
        for gender in ["ذكر", "أنثى"]:
            d = buckets.get((age, gender), {})
            total = sum(d.values())
            if total == 0:
                continue
            out.append({
                "age": age, "gender": gender, "total": total,
                "pct": {c: round(d.get(c, 0) / total * 100, 1) for c in cat_order},
            })
    return out


def _demographics(rows):
    def build(field, order=None):
        counts = defaultdict(int)
        for r in rows:
            v = r.get(field)
            if v:
                counts[v] += 1
        total = sum(counts.values()) or 1
        items = counts.items() if order is None else [(k, counts.get(k, 0)) for k in order]
        items = sorted(items, key=lambda kv: -kv[1]) if order is None else items
        return [{"label": k, "count": v, "pct": round(v / total * 100, 1)} for k, v in items if v > 0]

    return {
        "الجنس": build("الجنس"),
        "نوع المستفيد": build("نوع_المستفيد"),
        "الجنسية": build("الجنسية"),
    }


def _branches(rows):
    agg = defaultdict(lambda: {
        "count": 0, "wait_sum": 0, "service_sum": 0, "total_sum": 0,
        "rsum": 0, "rcount": 0, "wait_breach": 0, "service_breach": 0,
    })
    for r in rows:
        name = r.get("اسم_الفرع")
        if not name:
            continue
        b = agg[name]
        b["count"] += 1
        b["wait_sum"] += r.get("مدة_الانتظار_دقيقة") or 0
        b["service_sum"] += r.get("مدة_الخدمة_دقيقة") or 0
        b["total_sum"] += r.get("مدة_الإنجاز_الكلية_دقيقة") or 0
        rating = r.get("التقييم_%")
        if rating is not None:
            b["rsum"] += rating
            b["rcount"] += 1
        if r.get("تجاوز_هدف_الانتظار") == "نعم":
            b["wait_breach"] += 1
        if r.get("تجاوز_هدف_الخدمة") == "نعم":
            b["service_breach"] += 1

    out = []
    for name, b in agg.items():
        n = b["count"]
        out.append({
            "name": name, "count": n,
            "avg_wait": round(b["wait_sum"] / n, 2),
            "avg_service": round(b["service_sum"] / n, 2),
            "avg_total": round(b["total_sum"] / n, 2),
            "avg_rating": round(b["rsum"] / b["rcount"], 1) if b["rcount"] else 0,
            "wait_breach": b["wait_breach"],
            "service_breach": b["service_breach"],
        })
    out.sort(key=lambda x: -x["count"])
    return out


def _breach_factors(rows):
    svc_breach = defaultdict(int)
    svc_id = {}
    pri_breach = defaultdict(int)
    hour_breach = defaultdict(int)
    total_wait_breach = 0

    for r in rows:
        if r.get("تجاوز_هدف_الانتظار") != "نعم":
            continue
        total_wait_breach += 1
        name = r.get("اسم_الخدمة")
        if name:
            svc_breach[name] += 1
            svc_id[name] = r.get("معرف_الخدمة")
        pri = r.get("الأولوية")
        if pri:
            pri_breach[pri] += 1
        t = r.get("وقت_الحضور")
        if t:
            hour = str(t).split(":")[0].zfill(2)
            hour_breach[f"{hour}:00"] += 1

    top_svc = sorted(svc_breach.items(), key=lambda x: -x[1])[:5]
    top_hours = sorted(hour_breach.items(), key=lambda x: -x[1])[:5]

    return {
        "services": [{"name": k, "id": svc_id.get(k), "value": v} for k, v in top_svc],
        "priority": [{"name": k, "value": v} for k, v in sorted(pri_breach.items(), key=lambda x: -x[1])],
        "hours": [{"name": k, "value": v} for k, v in top_hours],
        "total_wait_breach": total_wait_breach,
    }


def _top_services(rows, top_n=10):
    svc_count = defaultdict(int)
    svc_id = {}
    svc_rating = defaultdict(list)
    for r in rows:
        name = r.get("اسم_الخدمة")
        if not name:
            continue
        svc_count[name] += 1
        svc_id[name] = r.get("معرف_الخدمة")
        rating = r.get("التقييم_%")
        if rating is not None:
            svc_rating[name].append(rating)

    top = sorted(svc_count.items(), key=lambda x: -x[1])[:top_n]
    total_all = sum(svc_count.values()) or 1
    cum = 0
    out = []
    for name, cnt in top:
        cum += cnt
        ratings = svc_rating.get(name, [])
        avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else 0
        out.append({
            "name": name, "id": svc_id.get(name), "count": cnt,
            "cum_pct": round(cum / total_all * 100, 1), "avg_rating": avg_rating,
        })
    return out, len(svc_count)


def _entity_distribution(rows):
    counts = defaultdict(int)
    for r in rows:
        e = r.get("اسم_الجهة")
        if e:
            counts[e] += 1
    return sorted([{"name": k, "count": v} for k, v in counts.items()], key=lambda x: -x["count"])


def _heatmap(rows):
    day_order = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"]

    def hour_bin(h):
        h = int(h)
        start = (h // 2) * 2
        return f"{start:02d}-{start + 2:02d}"

    bins = [f"{i:02d}-{i + 2:02d}" for i in range(0, 24, 2)]
    heat = defaultdict(int)
    for r in rows:
        day = r.get("اليوم")
        t = r.get("وقت_الحضور")
        if not day or not t:
            continue
        b = hour_bin(str(t).split(":")[0])
        heat[(day, b)] += 1

    matrix = []
    for day in day_order:
        matrix.append({"day": day, "values": [heat.get((day, b), 0) for b in bins]})
    max_heat = max(heat.values()) if heat else 1
    return {"days": day_order, "bins": bins, "matrix": matrix, "max": max_heat}


def _age_volume(rows):
    age_order = ["أقل من 18", "18-25", "26-35", "36-45", "46-55", "56+"]
    vol = defaultdict(int)
    rating = defaultdict(list)
    for r in rows:
        a = r.get("الفئة_العمرية")
        if not a:
            continue
        vol[a] += 1
        rt = r.get("التقييم_%")
        if rt is not None:
            rating[a].append(rt)
    out = []
    for a in age_order:
        ratings = rating.get(a, [])
        out.append({
            "age": a, "count": vol.get(a, 0),
            "avg_rating": round(sum(ratings) / len(ratings), 1) if ratings else 0,
        })
    return out


def _wait_spc(rows):
    weekly = defaultdict(list)
    for r in rows:
        d = _to_date(r.get("تاريخ_الزيارة"))
        w = r.get("مدة_الانتظار_دقيقة")
        if d is None or w is None:
            continue
        iso = d.isocalendar()
        weekly[f"W{iso[1]:02d}"].append(w)

    if not weekly:
        return {"labels": [], "values": [], "mean": 0, "ucl": 0, "lcl": 0}

    ordered = sorted(weekly.items(), key=lambda kv: int(kv[0][1:]))
    labels = [k for k, _ in ordered]
    values = [round(sum(v) / len(v), 2) for _, v in ordered]
    mean_w = round(statistics.mean(values), 2)
    std_w = round(statistics.pstdev(values), 2) if len(values) > 1 else 0
    return {
        "labels": labels, "values": values, "mean": mean_w,
        "ucl": round(mean_w + 2 * std_w, 2), "lcl": round(max(0, mean_w - 2 * std_w), 2),
    }


def _service_stats(rows):
    total = defaultdict(int)
    breach = defaultdict(int)
    svc_id = {}
    rating = defaultdict(list)
    for r in rows:
        name = r.get("اسم_الخدمة")
        if not name:
            continue
        total[name] += 1
        svc_id[name] = r.get("معرف_الخدمة")
        rt = r.get("التقييم_%")
        if rt is not None:
            rating[name].append(rt)
        if r.get("تجاوز_هدف_الانتظار") == "نعم":
            breach[name] += 1

    out = []
    for name, n in total.items():
        b = breach.get(name, 0)
        ratings = rating.get(name, [])
        out.append({
            "name": name, "id": svc_id.get(name), "total": n, "breach": b,
            "rate": round(b / n * 100, 1),
            "avg_rating": round(sum(ratings) / len(ratings), 1) if ratings else 0,
        })
    out.sort(key=lambda x: -x["total"])
    return out


def _priority_stats(rows):
    total = defaultdict(int)
    breach = defaultdict(int)
    for r in rows:
        p = r.get("الأولوية")
        if not p:
            continue
        total[p] += 1
        if r.get("تجاوز_هدف_الانتظار") == "نعم":
            breach[p] += 1
    return [
        {"name": p, "total": n, "breach": breach.get(p, 0), "rate": round(breach.get(p, 0) / n * 100, 1)}
        for p, n in total.items()
    ]


def _employees_and_counters(rows):
    emp = defaultdict(lambda: {"count": 0, "svc_sum": 0, "rsum": 0, "rcount": 0, "svc_breach": 0, "branches": defaultdict(int)})
    counter = defaultdict(lambda: {"count": 0, "svc_sum": 0, "rsum": 0, "rcount": 0, "branches": defaultdict(int)})

    for r in rows:
        e = r.get("معرف_الموظف")
        c = r.get("معرف_الكاونتر")
        svc = r.get("مدة_الخدمة_دقيقة") or 0
        rating = r.get("التقييم_%")
        branch = r.get("اسم_الفرع")

        if e:
            d = emp[e]
            d["count"] += 1
            d["svc_sum"] += svc
            if rating is not None:
                d["rsum"] += rating
                d["rcount"] += 1
            if r.get("تجاوز_هدف_الخدمة") == "نعم":
                d["svc_breach"] += 1
            if branch:
                d["branches"][branch] += 1

        if c:
            dc = counter[c]
            dc["count"] += 1
            dc["svc_sum"] += svc
            if rating is not None:
                dc["rsum"] += rating
                dc["rcount"] += 1
            if branch:
                dc["branches"][branch] += 1

    emp_list = []
    for e, d in emp.items():
        n = d["count"]
        branch = max(d["branches"].items(), key=lambda kv: kv[1])[0] if d["branches"] else None
        emp_list.append({
            "id": e, "count": n,
            "avg_service": round(d["svc_sum"] / n, 2),
            "avg_rating": round(d["rsum"] / d["rcount"], 2) if d["rcount"] else 0,
            "breach_rate": round(d["svc_breach"] / n * 100, 1),
            "branch": branch,
        })

    counter_list = []
    for c, d in counter.items():
        n = d["count"]
        branch = max(d["branches"].items(), key=lambda kv: kv[1])[0] if d["branches"] else None
        counter_list.append({
            "id": c, "count": n,
            "avg_service": round(d["svc_sum"] / n, 2),
            "avg_rating": round(d["rsum"] / d["rcount"], 2) if d["rcount"] else 0,
            "branch": branch,
        })

    if not emp_list:
        return {
            "employees": [], "counters": [], "median_service": 0, "median_rating": 0,
            "correlation_service_rating": 0, "breach_avg": 0, "workload_std": 0,
            "workload_mean": 0, "total_employees": 0, "total_counters": 0,
        }

    svc_vals = [e["avg_service"] for e in emp_list]
    rat_vals = [e["avg_rating"] for e in emp_list]
    med_svc = round(statistics.median(svc_vals), 2)
    med_rat = round(statistics.median(rat_vals), 2)

    n = len(svc_vals)
    if n > 1 and statistics.pstdev(svc_vals) > 0 and statistics.pstdev(rat_vals) > 0:
        ms, mr = statistics.mean(svc_vals), statistics.mean(rat_vals)
        cov = sum((svc_vals[i] - ms) * (rat_vals[i] - mr) for i in range(n))
        sds = math.sqrt(sum((x - ms) ** 2 for x in svc_vals))
        sdr = math.sqrt(sum((x - mr) ** 2 for x in rat_vals))
        corr = round(cov / (sds * sdr), 3) if sds and sdr else 0
    else:
        corr = 0

    for e in emp_list:
        fast = e["avg_service"] <= med_svc
        high = e["avg_rating"] >= med_rat
        if fast and high:
            q = "نجوم الأداء"
        elif fast and not high:
            q = "سريع لكن يحتاج تحسين الرضا"
        elif not fast and high:
            q = "دقيق لكن أبطأ من المتوسط"
        else:
            q = "يحتاج تدريب ومتابعة"
        e["quadrant"] = q

    breach_avg = round(sum(e["breach_rate"] for e in emp_list) / len(emp_list), 1)
    counts = [e["count"] for e in emp_list]
    workload_std = round(statistics.pstdev(counts), 1) if len(counts) > 1 else 0
    workload_mean = round(statistics.mean(counts), 1)

    # efficiency score (0-100), same weighting used previously:
    # volume 25% + speed 30% + rating 30% + SLA adherence 15%
    def norm(vals, inverse=False):
        lo, hi = min(vals), max(vals)
        rng = (hi - lo) or 1
        return lambda v: (1 - (v - lo) / rng) if inverse else (v - lo) / rng

    counts_all = [e["count"] for e in emp_list]
    n_count = norm(counts_all)
    n_svc = norm(svc_vals, inverse=True)
    n_rat = norm(rat_vals)
    breach_vals = [e["breach_rate"] for e in emp_list]
    n_breach = norm(breach_vals, inverse=True)
    for e in emp_list:
        score = (n_count(e["count"]) * 0.25 + n_svc(e["avg_service"]) * 0.3
                 + n_rat(e["avg_rating"]) * 0.3 + n_breach(e["breach_rate"]) * 0.15)
        e["efficiency_score"] = round(score * 100, 1)

    emp_list.sort(key=lambda x: -x["efficiency_score"])
    counter_list.sort(key=lambda x: -x["count"])

    return {
        "employees": emp_list, "counters": counter_list,
        "median_service": med_svc, "median_rating": med_rat,
        "correlation_service_rating": corr, "breach_avg": breach_avg,
        "workload_std": workload_std, "workload_mean": workload_mean,
        "total_employees": len(emp_list), "total_counters": len(counter_list),
    }


# ---------------------------------------------------------------------------
# نقطة الدخول العامة
# ---------------------------------------------------------------------------

def build_dashboard_data(excel_path: str) -> dict:
    """
    يقرأ ورقة 'طلبات_محسنة' من الإكسل ويعيد قاموس واحد يطابق تماماً الشكل
    الذي كانت تتوقعه Dashboard سابقاً من DATA الثابتة، بحيث لا يحتاج
    JavaScript إلى أي تعديل في بنية القراءة — فقط مصدر البيانات تغيّر.
    """
    rows = load_rows(excel_path)

    top_services, total_unique_services = _top_services(rows)

    return {
        "kpi": _kpi(rows),
        "monthly": _monthly(rows),
        "channel": _channel(rows),
        "sla": _sla(rows),
        "satisfaction_breakdown": _satisfaction_breakdown(rows),
        "demographics": _demographics(rows),
        "branches": _branches(rows),
        "breach_factors": _breach_factors(rows),
        "employees_page": _employees_and_counters(rows),
        "top_services": top_services,
        "total_unique_services": total_unique_services,
        "entity_distribution": _entity_distribution(rows),
        "heatmap": _heatmap(rows),
        "age_volume": _age_volume(rows),
        "wait_spc": _wait_spc(rows),
        "service_stats": _service_stats(rows),
        "priority_stats": _priority_stats(rows),
        "row_count": len(rows),
    }
