# -*- coding: utf-8 -*-
"""
app.py — Flask Backend لمشروع "وجّهني"
========================================

يربط هذا الملف بين:
  1) core/rag_engine.py       — يحدد الخدمة المناسبة لطلب المستفيد (بدون أي تعديل على منطقه)
  2) core/ticket_generator.py — يصدر التذكرة (بدون أي تعديل على منطقه)
  3) core/excel_writer.py     — يضيف سطر التذكرة الجديد إلى data/sedco_dashboard_full_3000_formatted.xlsx
  4) core/data_pipeline.py    — يعيد حساب كل مؤشرات Dashboard من الإكسل المحدَّث
  5) templates/index.html + static/script.js — تعرض Dashboard وتُحدَّث تلقائياً عبر Polling

تدفق العمل الكامل بعد أي تذكرة:
  طلب المستفيد → RAG يحدد الخدمة → ticket_generator يصدر التذكرة
      → excel_writer يضيف سطراً جديداً إلى الإكسل
      → في دورة الـ Polling التالية (كل ثانيتين) يطلب المتصفح GET /dashboard-data
      → data_pipeline يعيد قراءة الإكسل بالكامل ويحسب كل شيء من جديد
      → static/script.js يعيد تشغيل Linear Regression و Rule-Based Recommendation Engine
        على البيانات الجديدة تلقائياً (هذا المنطق موجود مسبقاً في script.js ولم يتغير)
      → Dashboard تتحدث بدون أي Refresh يدوي
"""

import os
import sys
import threading
import time

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv

from core.data_pipeline import build_dashboard_data
from core.excel_writer import append_ticket_to_excel

# ── تحميل الإعدادات ─────────────────────────────────────────────────────
load_dotenv("config.env")

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
LLAMA_MODEL = os.getenv("LLAMA_MODEL", "llama-3.3-70b-versatile")
SERVICES_FILE = os.getenv("SERVICES_FILE", "data/services.json")
EXCEL_PATH = os.getenv("EXCEL_PATH", "data/sedco_dashboard_full_3000_formatted.xlsx")
OUTPUT_FOLDER = "output"

app = Flask(__name__)

# ── تهيئة محرك RAG ومولّد التذاكر (مرة واحدة عند إقلاع السيرفر) ────────
# لا نغيّر منطق rag_engine.py أو ticket_generator.py إطلاقاً — فقط نستوردهما ونشغّلهما.
_engine = None
_ticket_gen = None
_engine_error = None


def _init_engine():
    """يهيئ RAG Engine مرة واحدة. لو مفتاح Groq غير موجود، لا يوقف تشغيل السيرفر —
    فقط يعطّل نقطة /submit-request مع رسالة خطأ واضحة."""
    global _engine, _ticket_gen, _engine_error
    try:
        from core.rag_engine import WajhniRAGEngine
        from core.ticket_generator import TicketGenerator

        if not GROQ_API_KEY or GROQ_API_KEY == "your_groq_api_key_here":
            _engine_error = (
                "مفتاح GROQ_API_KEY غير موجود في config.env. "
                "أضِف مفتاحك من https://console.groq.com حتى يعمل /submit-request."
            )
            return

        engine = WajhniRAGEngine(
            services_file=SERVICES_FILE,
            api_key=GROQ_API_KEY,
            model_name=LLAMA_MODEL,
        )
        engine.initialize()
        _engine = engine
        _ticket_gen = TicketGenerator(output_folder=OUTPUT_FOLDER)
        print("✅ تهيئة RAG Engine و Ticket Generator تمت بنجاح.")
    except Exception as exc:  # noqa: BLE001 — نريد أي خطأ تهيئة ألا يوقف السيرفر
        _engine_error = f"تعذّرت تهيئة RAG Engine: {exc}"
        print("⚠️", _engine_error)


_init_engine()


# ── كاش بسيط لبيانات Dashboard مبني على وقت تعديل الملف (mtime) ────────
# هذا لتفادي إعادة قراءة إكسل بحجم 3000+ سطر من القرص في كل طلب Polling
# (كل ثانيتين لكل متصفح مفتوح) بينما الملف لم يتغيّر فعلياً. أي تعديل
# فعلي على الملف (تذكرة جديدة) يغيّر mtime فوراً فتُعاد القراءة والحساب.
_cache_lock = threading.Lock()
_cache = {"mtime": None, "data": None}


def get_dashboard_data(force: bool = False) -> dict:
    with _cache_lock:
        try:
            mtime = os.path.getmtime(EXCEL_PATH)
        except OSError:
            mtime = None

        if force or _cache["data"] is None or _cache["mtime"] != mtime:
            try:
                _cache["data"] = build_dashboard_data(EXCEL_PATH)
                _cache["mtime"] = mtime
            except Exception:
                # قراءة نادرة تزامنت مع لحظة كتابة تذكرة جديدة على نفس الملف —
                # نُبقي آخر بيانات صحيحة معروضة، ودورة الـ Polling التالية (بعد ثانيتين) تعيد المحاولة
                if _cache["data"] is None:
                    raise

        return _cache["data"]


# ── المسارات (Routes) ───────────────────────────────────────────────────

@app.route("/")
def index():
    """يعرض Dashboard (نفس التصميم الحالي 100%، بدون أي تعديل على HTML/CSS)."""
    return render_template("index.html")


@app.route("/kiosk")
def kiosk():
    """
    يعرض واجهة الكيوسك (نفس واجهة lastnite50/wajhni-api على Hugging Face
    Spaces، بنفس التصميم والألوان تماماً) — لكن معدَّلة لتتصل بنفس Backend
    الحالي مباشرة (/match-service ثم /issue-ticket) بدل خادم Vercel
    المنفصل، بحيث تصبح التذاكر حقيقية وتنعكس على Dashboard فوراً.
    """
    return render_template("kiosk.html")


@app.route("/dashboard-data")
def dashboard_data():
    """
    GET /dashboard-data
    يعيد جميع بيانات Dashboard بصيغة JSON: KPI Cards, Charts Data,
    Forecast History (شهرياً — النموذج التنبؤي نفسه يعمل في script.js),
    Recommendation Engine context, بيانات الموظفين/الفروع/الخدمات... إلخ.
    مُحسوبة مباشرة من data/sedco_dashboard_full_3000_formatted.xlsx.
    """
    try:
        data = get_dashboard_data()
        return jsonify(data)
    except Exception as exc:  # noqa: BLE001
        return jsonify({"error": True, "message": f"تعذّر قراءة بيانات اللوحة: {exc}"}), 500


def _validate_gender_status(payload):
    gender = payload.get("gender")
    status = payload.get("status")
    if gender not in ("ذكر", "أنثى"):
        return None, None, ("الحقل 'gender' يجب أن يكون 'ذكر' أو 'أنثى'.", 400)
    if status not in ("مواطن", "مقيم"):
        return None, None, ("الحقل 'status' يجب أن يكون 'مواطن' أو 'مقيم'.", 400)
    return gender, status, None


@app.route("/match-service", methods=["POST"])
def match_service():
    """
    POST /match-service
    Body: { "text": "...", "gender": "ذكر|أنثى", "status": "مواطن|مقيم" }

    الخطوة الأولى فقط: RAG (core/rag_engine.py) يحدد الخدمة المناسبة —
    بدون إصدار تذكرة وبدون أي كتابة على ملف الإكسل. هذا يسمح لواجهة
    الكيوسك بعرض شاشة "تأكيد الخدمة" أو "توضيح إضافي" قبل الالتزام
    بإصدار تذكرة فعلية، تماماً كما تتوقع واجهة المستخدم الحالية.
    """
    if _engine is None:
        return jsonify({"error": True, "message": _engine_error or "محرك RAG غير مهيأ."}), 503

    payload = request.get_json(silent=True) or {}
    user_text = (payload.get("text") or payload.get("query") or "").strip()
    if not user_text:
        return jsonify({"error": True, "message": "الرجاء إرسال نص الطلب في الحقل 'text'."}), 400

    gender, status, err = _validate_gender_status(payload)
    if err:
        return jsonify({"error": True, "message": err[0]}), err[1]

    service_result = _engine.process_request(user_text)
    if service_result.get("error"):
        return jsonify(service_result), 200  # نُعيدها كما هي — الواجهة تتعامل مع error:true بنفسها

    service_result["gender"] = gender
    service_result["status"] = status
    return jsonify(service_result)


@app.route("/issue-ticket", methods=["POST"])
def issue_ticket():
    """
    POST /issue-ticket
    Body: { "service_result": {...ناتج /match-service...}, "gender": "...", "status": "..." }

    الخطوة الثانية: تُستدعى فقط بعد أن يؤكد المستفيد الخدمة (أو مباشرة لو
    كانت الثقة عالية). هذه هي النقطة الوحيدة التي:
      1) تصدر تذكرة فعلية عبر core/ticket_generator.py
      2) تضيف سطراً جديداً إلى ملف الإكسل عبر core/excel_writer.py
      3) تُبطل كاش /dashboard-data فوراً
    بحيث تنعكس التذكرة على Dashboard خلال ثانيتين كحد أقصى.
    """
    if _ticket_gen is None:
        return jsonify({"error": True, "message": _engine_error or "مولّد التذاكر غير مهيأ."}), 503

    payload = request.get_json(silent=True) or {}
    service_result = payload.get("service_result")
    if not isinstance(service_result, dict) or not service_result.get("service_name"):
        return jsonify({"error": True, "message": "الحقل 'service_result' مفقود أو غير صالح."}), 400

    gender, status, err = _validate_gender_status(payload)
    if err:
        return jsonify({"error": True, "message": err[0]}), err[1]

    service_result = dict(service_result)  # نسخة محلية حتى لا نعدّل بيانات المستدعي
    service_result["gender"] = gender
    service_result["status"] = status

    ticket_result = _ticket_gen.generate(service_result)
    if ticket_result.get("error"):
        return jsonify({"error": True, "message": ticket_result.get("message", "تعذّر إصدار التذكرة.")}), 500

    try:
        new_row = append_ticket_to_excel(EXCEL_PATH, service_result, ticket_result, gender, status)
    except Exception as exc:  # noqa: BLE001
        return jsonify({
            "error": True,
            "message": f"صدرت التذكرة لكن تعذّر تحديث ملف الإكسل: {exc}",
            "ticket": ticket_result,
        }), 500

    get_dashboard_data(force=True)

    return jsonify({
        "error": False,
        "waiting_number": ticket_result.get("waiting_number"),
        "wait_info": ticket_result.get("wait_info"),
        "department": ticket_result.get("department"),
        "window_number": ticket_result.get("window_number"),
        "service_name": ticket_result.get("service_name"),
        "ticket_text": ticket_result.get("ticket_text"),
        "excel_row_added": new_row,
    })


@app.route("/submit-request", methods=["POST"])
def submit_request():
    """
    POST /submit-request
    Body (JSON): { "text": "...", "gender": "ذكر|أنثى", "status": "مواطن|مقيم" }

    نقطة نهاية موحّدة (تشغّل match-service ثم issue-ticket تلقائياً في نداء
    واحد) — مناسبة للاختبار السريع عبر curl أو لتكامل لا يحتاج شاشة تأكيد
    وسيطة. واجهة الكيوسك الفعلية (templates/kiosk.html) تستخدم بدلاً منها
    /match-service ثم /issue-ticket بشكل منفصل، لأن تجربة المستخدم فيها
    شاشة "تأكيد" أو "توضيح" قبل الالتزام بإصدار تذكرة فعلية.
    """
    if _engine is None:
        return jsonify({"error": True, "message": _engine_error or "محرك RAG غير مهيأ."}), 503

    payload = request.get_json(silent=True) or {}
    user_text = (payload.get("text") or payload.get("query") or "").strip()

    if not user_text:
        return jsonify({"error": True, "message": "الرجاء إرسال نص الطلب في الحقل 'text'."}), 400

    gender, status, err = _validate_gender_status(payload)
    if err:
        return jsonify({"error": True, "message": err[0]}), err[1]

    # 1) RAG يحدد الخدمة
    service_result = _engine.process_request(user_text)
    if service_result.get("error"):
        return jsonify({"error": True, "message": service_result.get("message", "تعذّر تحديد الخدمة.")}), 502

    service_result["gender"] = gender
    service_result["status"] = status

    # 2) توليد التذكرة
    ticket_result = _ticket_gen.generate(service_result)
    if ticket_result.get("error"):
        return jsonify({"error": True, "message": ticket_result.get("message", "تعذّر إصدار التذكرة.")}), 500

    # 3) تحديث ملف الإكسل مباشرة
    try:
        new_row = append_ticket_to_excel(EXCEL_PATH, service_result, ticket_result, gender, status)
    except Exception as exc:  # noqa: BLE001
        return jsonify({
            "error": True,
            "message": f"صدرت التذكرة لكن تعذّر تحديث ملف الإكسل: {exc}",
            "ticket": ticket_result,
        }), 500

    # 4) إبطال الكاش فوراً حتى يعكس /dashboard-data التالي البيانات الجديدة
    get_dashboard_data(force=True)

    return jsonify({
        "error": False,
        "service": service_result,
        "ticket": {
            "waiting_number": ticket_result.get("waiting_number"),
            "wait_info": ticket_result.get("wait_info"),
            "department": ticket_result.get("department"),
            "window_number": ticket_result.get("window_number"),
            "service_name": ticket_result.get("service_name"),
            "ticket_text": ticket_result.get("ticket_text"),
        },
        "excel_row_added": new_row,
    })


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "engine_ready": _engine is not None,
        "engine_error": _engine_error,
        "excel_path": EXCEL_PATH,
        "excel_exists": os.path.exists(EXCEL_PATH),
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=True, use_reloader=False)
